const TAX = 3;
const SHIPPING = 0;

const subtotalEl = document.getElementById("subtotal");
const taxEl = document.getElementById("tax");
const totalEl = document.getElementById("total");
const liveRegion = document.getElementById("live-region");

function updateSummary() {
  let subtotal = 0;
  let totalQuantity = 0;

  document.querySelectorAll("[data-product-id]").forEach(product => {
    const qtyEl = product.querySelector("[data-role='qty']");
    const priceEl = product.querySelector(".w-24 .font-medium");

    const qty = parseInt(qtyEl.textContent.trim(), 10);
    const price = parseFloat(priceEl.textContent.replace("$", ""));

    subtotal += qty * price;
    totalQuantity += qty;
  });

  const appliedTax = totalQuantity > 0 ? TAX : 0;

  subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
  taxEl.textContent = `$${appliedTax.toFixed(2)}`;

  const total = subtotal + appliedTax + SHIPPING;
  totalEl.textContent = `$${total.toFixed(2)}`;
}

function updateQty(product, delta) {
  const qtyEl = product.querySelector("[data-role='qty']");
  let currentQty = parseInt(qtyEl.textContent.trim(), 10);

  let newQty = currentQty + delta;
  if (newQty < 0) newQty = 0;

  qtyEl.textContent = newQty;

  updateSummary();
}

function deleteProduct(product) {
  const qtyEl = product.querySelector("[data-role='qty']");
  qtyEl.textContent = "0";

  liveRegion.textContent = `${product.dataset.productId} set to 0`;

  updateSummary();
}

document.querySelectorAll("[data-product-id]").forEach(product => {
  const productId = product.dataset.productId;
  product.querySelectorAll(".qty-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const action = btn.dataset.action;
      updateQty(product, action === "increment" ? 1 : -1);
    });
  });

  const deleteBtn = product.querySelector("[data-action='delete']");
  deleteBtn.addEventListener("click", () => {
    deleteProduct(product);
  });
});

updateSummary();